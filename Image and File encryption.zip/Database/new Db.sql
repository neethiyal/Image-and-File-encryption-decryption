-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.0.67-community-nt - MySQL Community Edition (GPL)
-- Server OS:                    Win32
-- HeidiSQL Version:             11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for imageencrypt
CREATE DATABASE IF NOT EXISTS `imageencrypt` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `imageencrypt`;

-- Dumping structure for table imageencrypt.file
CREATE TABLE IF NOT EXISTS `file` (
  `fid` int(11) NOT NULL auto_increment,
  `pname` varchar(50) default NULL,
  `phone` varchar(50) default NULL,
  `address` varchar(50) default NULL,
  `hname` varchar(50) default NULL,
  `image` blob,
  `file` varchar(500) default NULL,
  `dkey` varchar(500) default NULL,
  PRIMARY KEY  (`fid`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

-- Dumping data for table imageencrypt.file: ~2 rows (approximately)
/*!40000 ALTER TABLE `file` DISABLE KEYS */;
INSERT INTO `file` (`fid`, `pname`, `phone`, `address`, `hname`, `image`, `file`, `dkey`) VALUES
	(6, 'DHIVYA', '7845124578', 'chennai', 'PNS Hospital', _binary 0x433a5c55736572735c4a6176615c446f63756d656e74735c656e635c37, 'C:\\Users\\Java\\Documents\\text doc\\2.txt.enc', '1234567891234567'),
	(7, 'Neethiyal', '7845965874', 'chennai', 'SNS Hospital', _binary 0x433a5c55736572735c4a6176615c446f63756d656e74735c65696d675c6331, 'C:\\Users\\Java\\Documents\\text doc\\1.txt.enc', '1234567891234567');
/*!40000 ALTER TABLE `file` ENABLE KEYS */;

-- Dumping structure for table imageencrypt.hospital
CREATE TABLE IF NOT EXISTS `hospital` (
  `hid` int(11) NOT NULL auto_increment,
  `hname` varchar(50) default NULL,
  `address` varchar(50) default NULL,
  `password` varchar(50) default NULL,
  PRIMARY KEY  (`hid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Dumping data for table imageencrypt.hospital: ~4 rows (approximately)
/*!40000 ALTER TABLE `hospital` DISABLE KEYS */;
INSERT INTO `hospital` (`hid`, `hname`, `address`, `password`) VALUES
	(1, 'ABC Hospital', 'Velachery', '1212'),
	(2, 'XYZ Hospital', 'T.nagar', '1212'),
	(3, 'SNS Hospital', 'Ambattur', '1212'),
	(4, 'PNS Hospital', 'Perambur', '1212');
/*!40000 ALTER TABLE `hospital` ENABLE KEYS */;

-- Dumping structure for table imageencrypt.res
CREATE TABLE IF NOT EXISTS `res` (
  `rid` int(11) NOT NULL auto_increment,
  `hname` varchar(50) NOT NULL default '0',
  `fid` int(11) NOT NULL default '0',
  `pname` varchar(50) NOT NULL default '0',
  `consult` varchar(500) NOT NULL default '0',
  PRIMARY KEY  (`rid`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

-- Dumping data for table imageencrypt.res: ~2 rows (approximately)
/*!40000 ALTER TABLE `res` DISABLE KEYS */;
INSERT INTO `res` (`rid`, `hname`, `fid`, `pname`, `consult`) VALUES
	(14, 'PNS Hospital', 6, 'DHIVYA', 'Health condition is very critical need to  admit in hospital immediatly\n'),
	(16, 'SNS Hospital', 7, 'Neethiyal', 'your condition is stable.');
/*!40000 ALTER TABLE `res` ENABLE KEYS */;

-- Dumping structure for table imageencrypt.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL default '0',
  `username` varchar(50) NOT NULL default '0',
  `email` varchar(50) NOT NULL default '0',
  `phone` varchar(50) NOT NULL default '0',
  `address` varchar(50) NOT NULL default '0',
  `pass` varchar(50) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

-- Dumping data for table imageencrypt.users: ~3 rows (approximately)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `name`, `username`, `email`, `phone`, `address`, `pass`) VALUES
	(9, 'Sara', 'sara5', 'sara@gmail.com', '7485963215', 'banglore', '1212'),
	(10, 'Dhivya', 'dive', 'dhivya@gmail.com', '7845124578', 'chennai', '1212'),
	(11, 'Neethiyal', 'sharon', 'sharon@gmail.com', '7845965874', 'chennai', '1212');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
